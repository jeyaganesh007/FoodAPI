package com.example.foodapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
